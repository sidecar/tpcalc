<?php
session_start();

//password code
if(isset($_GET['logout']) && isset($_SESSION['authed'])) $_SESSION['authed'] = false;
if(!isset($_SESSION['authed']) || !$_SESSION['authed']) {

	if(isset($_POST['passwd']) && crypt($_POST['passwd'],'gy')=='gynr1u6NcWWpw') {
		$_SESSION['authed'] = true;
	} else {
		print "<form method=\"post\">Enter password: <input type=\"password\" name=\"passwd\"><input type=\"submit\" value=\"Log In\">";
		if(isset($_REQUEST['table'])) print "<input type=\"hidden\" name=\"table\" value=\"{$_REQUEST['table']}\">";
		print "</form>";
		exit();
	}
}
//end password code


if(!isset($_POST['to'])) {
//var_dump($_POST);
print "<form method=\"post\">";
print "From Email:<input type=\"text\" name=\"fr\"/>...From Name<input type=\"text\" name=\"fn\"/><br>";
print "To:<input type=\"text\" name=\"to\"/ size=\"100\"><br>";
print "Re:<input type=\"text\" name=\"re\"/><br>";
print "HTML Message:<br><textarea name=\"em\" cols=\"70\" rows=\"10\"></textarea><br>";
print "<input type=\"submit\" value=\"Send\"/></form>";

} else {

//to,subject,body,headers
$hdrs = "From: \"{$_POST['fn']}\"<{$_POST['fr']}>\n";
$hdrs.= "Content-Type: text/html; charset=iso-8859-1\n";
$msg = stripslashes($_POST['em']);
$to_all = explode(',',$_POST['to']);
if(count($to_all) > 10) exit("too many recipients");
foreach($to_all as $to) {
	mail($to,$_POST['re'],$msg,$hdrs);
}

print "sent";
}
?>
